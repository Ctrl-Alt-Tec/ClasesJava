package ClasesJava.Clase6;

public class main {
    /**Problema 1 
     * Ve a la clase Alumno y corríegela
    */
    /**Problema 2
     * Ve a la clase salón y complétala.
     * Una vez que esté completa, termina
     * los métodos de estaRegistrado y 
     * alumnosFaltantes. 
     */
    public static void main(String[] args) {
        /**Problema 1 */
        //Primero verifica que ya funcione la clase Alumno
        //Esto hazlo al construir un alumno y llamar
        //a su método de presentar
        
        /**Problema 2 */
        //Array para problema 2
        /** QUITA LOS COMENTARIOS CUANDO QUIERAS PROBARLO
        Alumno asistentes_de_hoy [] = { //Notese que lo escribí de manera diferente, usen el que más les guste :)
                                new Alumno("Juanito", 10),
                                new Alumno("Pedrito", 10),
                                new Alumno("Anita", 10),
                                new Alumno("Maria", 10)};
        */
        
        //Primero crea una clase Salón.
        //Verifica que esté funcionando con el método de mostrarSalon

        
        

    }

    //Más en snake_case
    //https://medium.com/better-programming/string-case-styles-camel-pascal-snake-and-kebab-case-981407998841
}