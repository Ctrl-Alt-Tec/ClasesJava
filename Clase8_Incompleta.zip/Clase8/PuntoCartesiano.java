package ClasesJava.Clase8;

public class PuntoCartesiano {
    //Atributos:

    //Constructor
    public PuntoCartesiano(){

    }
    //Getters
     

}