package ClasesJava.Clase8;

public class Cuadrilatero {
    public Cuadrilatero(){

    }
    /**
     * Método para saber si es un cuadrado
     * Método para saber si es un rectángulo
     * Método para saber si es irregular
     * Método para saber su área
     * Método para conocer su perímetro
     */
    
    
    
    
    
}