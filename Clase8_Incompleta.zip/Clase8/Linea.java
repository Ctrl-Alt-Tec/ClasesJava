package ClasesJava.Clase8;

public class Linea {
    //Atributos

    //Constructor
    public Linea(){

    }

    //Método para obtener la longitud de la línea
    //Método para saber si dos líneas son paralelas
        
}