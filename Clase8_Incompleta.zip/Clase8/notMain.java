package ClasesJava.Clase8;

public class notMain {
    public static void main(String[] args) {
        /**
         * Ejercicio 1:
         * * Crea la clase PuntoCartesiano
         * Comprueba que funciona creando un objeto del tipo
         * Y muestra sus coordenadas en formato (X,Y)
         */

        
        /**
         * Ejercicio 2:
         * * Crea la clase Linea
         * * Incluye los métodos especificados
         * Comprueba que funciona creando un objeto del tipo
         * Muestra su su longitud y puntos de inicio en el formato (X,Y)
         */


        /**
         * Ejercicio 3:
         * * Crea la clase Triángulo
         * * Incluye los métodos especificados
         * Comprueba que funciona creando un objeto del tipo
         * Muestra su área y su tipo
         */

        /**
         * Ejercicio 4:
         * * Crea la clase Cuadrado
         * * Incluye los métodos especificados
         * Comprueba que funciona creando un objeto del tipo
         * Muestra su área y su tipo
         * Si es un cuadrado, haz que se dibuje, ocupando el programa de
         * la clase pasada
         */
    }
}