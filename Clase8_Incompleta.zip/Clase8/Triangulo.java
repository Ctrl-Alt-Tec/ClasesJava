package ClasesJava.Clase8;

public class Triangulo {
    //Atributos

    //Constructor
    public Triangulo (){

    }
    /**
     * Método para saber si es equilatero
     * Método para saber si es rectángulo
     * Método para saber si es isóceles
     * Método para saber si es escaleno
     * Método para saber su área
     * Método para conocer su perímetro
     */
    
}