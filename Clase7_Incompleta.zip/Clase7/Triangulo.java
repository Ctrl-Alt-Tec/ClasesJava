package ClasesJava.Clase7;

public class Triangulo {
    public Triangulo(){
        
    }
}