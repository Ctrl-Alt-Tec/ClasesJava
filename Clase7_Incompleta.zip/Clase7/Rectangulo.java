package ClasesJava.Clase7;

public class Rectangulo {
    public Rectangulo(){
        
    }
}