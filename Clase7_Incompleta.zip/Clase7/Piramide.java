package ClasesJava.Clase7;

public class Piramide {
    public Piramide(){
        
    }
}