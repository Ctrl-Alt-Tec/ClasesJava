package ClasesJava.Clase7;

public class Casa {
    public Casa (){
        
    }
}